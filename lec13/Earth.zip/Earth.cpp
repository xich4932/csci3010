#include <iostream>

#include "Earth.h"

const int Earth::NUM_CONTINENTS = 7;

Earth::Earth() {
    // Implement your constructor here
    // make sure to initialize your fields!
}
